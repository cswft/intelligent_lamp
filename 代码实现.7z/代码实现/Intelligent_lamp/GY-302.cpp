#include "GY-302.h"

byte buff[2];
int BH1750address = 0x23;

uint16_t Get_illumination()         //得到光照传感器的值并返回

{

 int i;

 uint16_t val=0;

 BH1750_Init(BH1750address);

 delay(200);

 if(2==BH1750_Read(BH1750address))

  {

   val=((buff[0]<<8)|buff[1])/1.2;

   Serial.print(val);     

   Serial.println("[lx]....."); 

  }

 //delay(150);

 return val;
 

}




int BH1750_Read(int address) //

{

  int i=0;

  Wire.beginTransmission(address);  //发送数据到设备号为address的从机

  Wire.requestFrom(address, 2);   //通知从机上传两个字节

  while(Wire.available()) // 主机接收到从机数据时

  {

    buff[i] = Wire.read();  // receive one byte

    i++;

  }

  Wire.endTransmission();  //停止发送

  return i;

}




void BH1750_Init(int address) 

{

  Wire.beginTransmission(address);  //发送数据到设备号为address的从机

  Wire.write(0x10);//1lx reolution 120ms

  Wire.endTransmission();   

}
