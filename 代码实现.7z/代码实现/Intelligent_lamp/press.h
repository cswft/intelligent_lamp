#ifndef _PRESS_H_
#define _PRESS_H_

#include <Ticker.h>
#include <ESP8266WiFi.h>




 
#define UP_KEY  13 //按键引脚定义

void flip();    //定时器里检测按键状态并计数

#endif
