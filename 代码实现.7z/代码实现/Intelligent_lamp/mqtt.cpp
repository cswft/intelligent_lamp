#include"mqtt.h"
#include"ws2812.h"
extern const char* ssid ;
extern const char* password ;
extern const char* mqtt_server ;
extern const char* user ;
extern const char* pass ;
extern uint8_t  period_minute;  //番茄时钟（时间间隔）
extern uint8_t  shortPressNum;
extern uint8_t  longPress;
extern uint8_t  typePress;
extern char     Shut_Beep;  //0为蜂鸣器关闭
extern char     led_switch;
extern Led myled;

WiFiClient espClient;
PubSubClient client(espClient);
unsigned long lastMsg = 0;
#define MSG_BUFFER_SIZE  (50)
char msg[MSG_BUFFER_SIZE];
int value = 0;

void setup_wifi() {

  delay(10);
  // We start by connecting to a WiFi network
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.mode(WIFI_STA);   //设置ESP8266工作模式
  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  randomSeed(micros());

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

void callback(char* topic, byte* payload, unsigned int length) {
  Serial.print("Message arrived [");
  Serial.print(topic);
  Serial.print("] ");
  for (int i = 0; i < length; i++) {
    Serial.print((char)payload[i]);
  }
  Serial.println();
  if((String)topic=="modeTopic")
  {
    if((char)payload[0]=='1')          //手机模式
     {
         typePress=1;
     }
     else if((char)payload[0]=='2')     //自动模式
     {
         typePress=2;
     }
     else                              //按键模式
     {
         typePress=3;
     }
  }
  else if((String)topic=="inTopic")
  {
     if((char)payload[0]=='1')   //开灯
     {
         led_switch=1;
     }
     else if((char)payload[0]=='0')   //关灯
     {
         led_switch=0;
     }
  }
  else if((String)topic=="colorTopic")
  {
    if((char)payload[0]=='1')     //白光
     {
         myled.mqtt_saturation = 0;
     }
     else if((char)payload[0]=='2')     //暖光
     {
         myled.mqtt_saturation = 175;
     }
  }
  
  else if((String)topic=="brightTopic")
  {
    if((char)payload[0]=='1')        //强光
     {
         myled.mqtt_bright=255;
     }
     else if((char)payload[0]=='2')   //中
     {
         myled.mqtt_bright=170;
     }
     else                      //弱
     {
         myled.mqtt_bright=85;
     }
  }
  else if((String)topic=="timeTopic")
  {
      if((char)payload[0]=='1')        period_minute=1;
      else if((char)payload[0]=='2')   period_minute=60;
      else if((char)payload[0]=='3')   period_minute=90;
      else                             period_minute=120;
  }
  else
  {
     if((char)payload[0]=='0')
     {
        Shut_Beep = 0;
        digitalWrite(15, LOW);  //关闭蜂鸣器 
     }   
  }
}

void reconnect() {
  // Loop until we're reconnected
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    // Create a random client ID
    String clientId = "ESP8266Client-";
    clientId += String(random(0xffff), HEX);
    Serial.println(clientId.c_str());
    // Attempt to connect
    if (client.connect(clientId.c_str(),user,pass)) {
      Serial.println("connected");
      // Once connected, publish an announcement...
      client.publish("outTopic", "hello world");
      // ... and resubscribe
      client.subscribe("inTopic");             //订阅主题
      client.subscribe("timeTopic"); 
      client.subscribe("colorTopic"); 
      client.subscribe("modeTopic"); 
      client.subscribe("brightTopic"); 
      client.subscribe("remindTopic"); 
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      // Wait 5 seconds before retrying
      delay(5000);
    }
//     client.publish("colorTopic","1"); 
//     client.publish("inTopic","0");
//     client.publish("modeTopic","3");
//     client.publish("brightTopic","1"); 
//     client.publish("timeTopic","2");
  }
}

void mqtt_setup() {
  Serial.begin(9600);
  setup_wifi();
  client.setServer(mqtt_server, 1883);
  client.setCallback(callback);
}

void mqtt_loop(){
  if (!client.connected()) {
    reconnect();
  }
  client.loop();
//  unsigned long now = millis();
//  if (now - lastMsg > 2000) {
//    lastMsg = now;
//    ++value;
//    snprintf (msg, MSG_BUFFER_SIZE, "hello world #%ld", value);
//    Serial.print("Publish message: ");
//    Serial.println(msg);
//    client.publish("outTopic", msg);
//  }
}

void mqtt_public(char* topic,char* msg)
{
    client.publish(topic, msg); 
}
