#ifndef _WS2812_H_
#define _WS2812_H_
#include"FastLED.h"     //FastLED库




class Led {
  public:
  uint8_t bright=255;//亮度控制变量0-255
  uint8_t mqtt_bright=255;
  uint8_t saturation=0;  //饱和度
  uint8_t mqtt_saturation=0;
  Led();//构造函数初始化灯带
  void Automatic_change_led(uint16_t illumination);//光照自动改变灯的亮度
  void Press_change_led(uint8_t num);//按键调节
  void Phone_change_led();//手机调节
  };


#endif
