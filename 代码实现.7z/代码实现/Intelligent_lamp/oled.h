#ifndef _OLED_H_
#define _OLED_H_
#include <ss_oled.h>
#include <BitBang_I2C.h>
#include <stdio.h>
#include <iostream>
#include <string.h>



void oled_loop();

void oled_setup();

#endif
