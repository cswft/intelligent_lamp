#include "press.h"



//读按键值
#define KEYU      digitalRead(UP_KEY)

#define short_press_time 10     //短按时间
#define long_press_time 1000    //长按时间

#define NO_KEY_PRES     0   //无按键按下

#define UP_KEY_PRES     1


#define UP_KEY_LONG_PRES     11

uint16_t KEYU_PRESS_COUNT = 0;//按KEYU时间计数


bool KEYU_UP = 0;//按键状态，0为弹起，1为按下


uint8_t KEYU_KEY_READ = NO_KEY_PRES;//KEYU按键状态

extern uint8_t longPress;//按键初始值为0,手动模式；长按后为1，自动模式
extern uint8_t typePress;

extern uint8_t shortPressNum;//按键短按的次数

extern char Shut_Beep;
//定时器里检测按键状态并计数
void flip() {
  //UP_KEY
  if (KEYU) {
    KEYU_PRESS_COUNT++;
    KEYU_UP = 1;
    if (KEYU_PRESS_COUNT <= short_press_time)
      KEYU_KEY_READ = NO_KEY_PRES;
    if (KEYU_PRESS_COUNT >= short_press_time && KEYU_PRESS_COUNT <= long_press_time)
      KEYU_KEY_READ = UP_KEY_PRES;
    if (KEYU_PRESS_COUNT >= long_press_time)
      KEYU_KEY_READ = UP_KEY_LONG_PRES;
  }
  if (KEYU == 0) {
    KEYU_PRESS_COUNT = 0;
    KEYU_UP = 0;//按键状态，0为弹起，1为按下
  }


//  if (KEYU_KEY_READ == UP_KEY_LONG_PRES && KEYU_UP == 0) {
//    if (typePress == 3) {                 //只有在按键模式下长按才有效
//      if (++longPress >= 2) {
//        longPress = 0;
//      }
//    }
//    Serial.print("--KEYU_UP长按--longPress=");
//    Serial.println(longPress);
//    KEYU_KEY_READ = NO_KEY_PRES;
//  }

  if (KEYU_KEY_READ == UP_KEY_PRES && KEYU_UP == 0) {
    if (Shut_Beep != 1 && typePress == 3) { //只有在按键模式下短按才有效
      if (++shortPressNum == 8) {
        shortPressNum = 1;
      }
    }
    if (Shut_Beep == 1) {
      Shut_Beep = 0;
      digitalWrite(15, LOW);  //关闭蜂鸣器
    }
    Serial.print("----KEYU_UP短按--shortPressNum=");
    Serial.println(shortPressNum);
    KEYU_KEY_READ = NO_KEY_PRES;
  }

}
