#include "time_get.h"
TimeClient timeClient;
TimeData timeData, lastTime;
//extern char*   Current_time;
extern char* Years;
extern char* Months;
extern char* Days;
extern char* Hours;
extern char* Minutes;
extern char* Seconds;

//unsigned long Unix_Time;
unsigned int year;
unsigned char month, day;
int year_tmp, month_tmp, day_tmp;
void RTC_Sync(unsigned long Unix_Time);
unsigned char Leap_Year_Judge(unsigned short year);
unsigned char last_day_of_mon(unsigned char month, unsigned short year);


TimeClient::TimeClient()
{
  timeClient = new NTPClient(ntpUDP, "pool.ntp.org", utcOffsetInSeconds);
  timeClient->begin();
}

void TimeClient::UpdateTime(TimeData& data)
{
  if (millis() - t > interval)   //millis()>0
  {
    timeClient->update();

    data.day = timeClient->getDay();
    data.hours = timeClient->getHours();
    data.minutes = timeClient->getMinutes();
    data.seconds = timeClient->getSeconds();
    data.unix_time = timeClient->getEpochTime();
    
    t = millis();
    last_sec = millis();
  }
  else
  {
    data.seconds += ((millis() - last_sec) / 1000);
    last_sec = millis();

    if (data.seconds > 59)
    {
      data.minutes++;
      data.seconds = 0;
    }

    if (data.minutes > 59)
    {
      data.hours++;
      data.minutes = 0;
    }

    if (data.hours > 23)
    {
      data.hours = 0;
    }
  }
}


void time_loop()
{
  // Get time through internet
  timeClient.UpdateTime(timeData);
  itoa(timeData.hours,Hours,10);
  itoa(timeData.minutes,Minutes,10);
  itoa(timeData.seconds,Seconds,10);
  Serial.print("Now the time is ");
  Serial.print(Hours);
  Serial.print(":");
  Serial.print(Minutes);
  Serial.print(":");
  Serial.println(Seconds);

  
  RTC_Sync(timeData.unix_time) ;
  
  itoa(year,Years,10);
  itoa(month,Months,10);
  itoa(day,Days,10);
  Serial.print(Years);
  Serial.print(":");
  Serial.print(Months);
  Serial.print(":");
  Serial.println(Days);
  delay(1000);
}

unsigned char Leap_Year_Judge(unsigned short year) { //判断该年是不是闰年
  if ((year % 400) == 0) {
    return 1;
  }
  else if ((year % 100) == 0) {
    return 0;
  }
  else if ((year % 4) == 0) {
    return 1;
  }
  else {
    return 0;
  }
}

unsigned char last_day_of_mon(unsigned char month, unsigned short year) {  //判断每月天数并在闰年时给2月+1天
  const unsigned char day_per_mon[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };  //每个月的天数
  if ((month == 0) || (month > 12)) {
    return day_per_mon[1] + Leap_Year_Judge(year);
  }

  if (month != 2) {
    return day_per_mon[month - 1];  //非2月直接返回对应月份天数
  }
  else {
    return day_per_mon[1] + Leap_Year_Judge(year);  //2月则判断该年是不是闰年
  }
}

void RTC_Sync(unsigned long Unix_Time) {  //计算时间数据

 // Unix_Time = timeClient->getEpochTime();  //获取当前Unix时间戳

  int days = Unix_Time / 86400L;  //算出1970-1-1至今天数
  for (year_tmp = 1970; days > 0; year_tmp++) {  //从1970开始减每年天数同时年份+1
    day_tmp = (365 + Leap_Year_Judge(year_tmp)); //这一年有多少天
    if (days >= day_tmp) {//条件成立，则year_tmp即是这个时间戳值所代表的年数。days剩下的数即为今年过了多少天。
      days -= day_tmp;
    }
    else {
      break;
    }
  }
  year = year_tmp ; //减去2000是因为时钟芯片仅接受2位数年份

  for (month_tmp = 1; month_tmp < 12; month_tmp++) { //计算今年过了几个月，方法同上
    day_tmp = last_day_of_mon(month_tmp, year);  //获取每个月的天数
    if (days >= day_tmp) {//条件成立，则month_tmp即是这个时间戳值所代表的月数。days剩下的数即为这个月过了多少天，即日。
      days -= day_tmp;
    }
    else {
      break;
    }
  }
  month = month_tmp;

  day = days + 1;
}
