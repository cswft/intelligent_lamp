#include "ws2812.h"
#include "mqtt.h"
#define NUM_LEDS 7             // LED灯珠数量
#define DATA_PIN 12              // Arduino输出控制信号引脚
#define LED_TYPE WS2812         // LED灯带型号
#define COLOR_ORDER RGB         // RGB灯珠中红色、绿色、蓝色LED的排列顺序
#define saturation_Warmcolor 175  //暖光的饱和度
#define saturation_Whitecolor 0    //白光的饱和度
extern uint8_t  typePress;
extern char     led_switch;
CRGB leds[NUM_LEDS];            // 建立光带leds

Led::Led() {
  LEDS.addLeds<LED_TYPE, DATA_PIN, COLOR_ORDER>(leds, NUM_LEDS);  // 初始化光带
}

void Led::Automatic_change_led(uint16_t illumination)  //通过光传感器自动改变灯亮度
{
  if (illumination >= 0 && illumination <= 510)
  {
    bright = 255 - illumination / 3;
  }
  else {
    bright = 0;
  }
  if(led_switch==1)   
  fill_solid(leds, 7, CHSV(80, mqtt_saturation, bright));
  else
  fill_solid(leds, 7, CRGB::Black);  //关灯
  FastLED.show();
  Serial.print("bright==");
  Serial.println(bright);
}

void Led::Press_change_led(uint8_t num) {         //按键切换灯的颜色、亮度、开关
//  if(num>=1&&num<=3)
//  {
//    saturation=0;   //mqtt_public("colorTopic","1");  mqtt_public("inTopic","1");    
//  }
//  else if(num>=4&&num<=6)
//  {
//    saturation=175;   //mqtt_public("colorTopic","2");   
//  }
//  else if(num==7)    // mqtt_public("inTopic","0");   
   
//  if(num==1||num==4)         mqtt_public("brightTopic","1"); 
//  else if(num==2||num==5)    mqtt_public("brightTopic","2");
//  else if(num==3||num==6)    mqtt_public("brightTopic","3"); 
  
  switch (num) {
    case 1: fill_solid(leds, 7, CHSV(80, 0, 255)); break; //开灯默认
    case 2: fill_solid(leds, 7, CHSV(80, 0, 170)); break;
    case 3: fill_solid(leds, 7, CHSV(80, 0, 85)); break;
    case 4: fill_solid(leds, 7, CHSV(80, 175, 255)); break;
    case 5: fill_solid(leds, 7, CHSV(80, 175, 170)); break;
    case 6: fill_solid(leds, 7, CHSV(80, 175, 85)); break;
    case 7: fill_solid(leds, 7, CRGB::Black); break;  //关灯
    default: break;
  }
  FastLED.show();

}

void Led::Phone_change_led(){
  if(led_switch==1)
   fill_solid(leds, 7, CHSV(80, mqtt_saturation, mqtt_bright));  
   else
   fill_solid(leds, 7, CRGB::Black);  //关灯
   FastLED.show();
}
