#ifndef _MQTT_H_
#define _MQTT_H_
#include <ESP8266WiFi.h>
#include <PubSubClient.h>

void setup_wifi();
void callback(char* topic, byte* payload, unsigned int length);
void reconnect();
void mqtt_setup();
void mqtt_loop();
void mqtt_public(char* topic,char* msg);
void public_setup();
#endif
