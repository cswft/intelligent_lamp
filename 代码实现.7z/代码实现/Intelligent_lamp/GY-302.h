#ifndef _GY-302_H_
#define _GY-302_H_
#include <Wire.h> //IIC

#include <math.h> 

#include <BH1750.h>

 



uint16_t Get_illumination();         //得到光照传感器的值并返回

int BH1750_Read(int address);

void BH1750_Init(int address) ;

#endif
