

#include "oled.h"

#define SDA_PIN 5
#define SCL_PIN 4
#define RESET_PIN -1
int rc;
extern  SSOLED oled;
extern char     Current_mode;
extern char   Current_time;
extern uint8_t  period_minute;  //番茄时钟（时间间隔）

//void oled_loop() {
//  //oledFill(&oled, 0, 1);
//  oledWriteString(&oled, 0, 0, 0, (String)*(Current_time), FONT_6x8, 0, 1);
//  for(uint8_t i=1;i<11;i++)
//      oledWriteString(&oled, 0, -1, -1, (String)*(Current_time+i), FONT_6x8, 0, 1); //要从最后一个位置继续写入set the x,y values to -1
//  oledWriteString(&oled, 0, 0, 1, "Current Mode:", FONT_6x8, 0, 1);
//  
//  if(Current_mode==1)
//      oledWriteString(&oled, 0, 8, 2, "PhonePress", FONT_6x8, 0, 1);
//  else if(Current_mode==3)
//       oledWriteString(&oled, 0, 8, 2,"  KeyPress", FONT_6x8, 0, 1);
//  else if(Current_mode==2)
//       oledWriteString(&oled, 0, 8, 2," Automatic", FONT_6x8, 0, 1);
//  
//  oledWriteString(&oled, 0, 0, 3, "TomatoClock:", FONT_6x8, 0, 1);
//
//  if(period_minute==1)
//       oledWriteString(&oled, 0, -1, -1, "1min", FONT_8x8, 0, 1); //从最后一个位置继续写入
//  else if(period_minute==60)
//       oledWriteString(&oled, 0, -1, -1, "1h  ", FONT_8x8, 0, 1);
//  else if(period_minute==90)
//       oledWriteString(&oled, 0, -1, -1, "1.5h", FONT_8x8, 0, 1);
//  else
//       oledWriteString(&oled, 0, -1, -1, "2h  ", FONT_8x8, 0, 1);
//}

void oled_setup() {
  rc = oledInit(&oled, OLED_128x32, 0x3c, 0, 0, 0, SDA_PIN, SCL_PIN, RESET_PIN, 1000000L);
  if (rc != OLED_NOT_FOUND)
  {
    oledFill(&oled, 0, 1);
//    oledSetContrast(&oled, 127);  //Sets the brightness (0=off, 255=brightest)
//    oledWriteString(&oled, 0, 0, 0, (char *)"Hello World", FONT_8x8, 0, 1);
  }
}

//#include "oled.h"
//
//#define SDA_PIN 5
//#define SCL_PIN 4
//#define RESET_PIN -1
//int rc;
//SSOLED oled;
//extern char     Current_mode;
//extern char*   Current_time;
//
//void oled_loop() {
//  //oledFill(&oled, 0, 1);
//  oledWriteString(&oled, 0, 0, 0, Current_time, FONT_6x8, 0, 1); //要从最后一个位置继续写入set the x,y values to -1
//  oledWriteString(&oled, 0, 0, 1, "Current Mode:", FONT_6x8, 0, 1);
//  if(Current_mode==0)
//      oledWriteString(&oled, 0, 8, 2, "KeyPress", FONT_6x8, 0, 1);
//  else if(Current_mode==1)
//       oledWriteString(&oled, 0, 8, 2, "Automatic", FONT_6x8, 0, 1);
//  oledWriteString(&oled, 0, 0, 3, "TomatoClock:", FONT_6x8, 0, 1);
//  oledWriteString(&oled, 0, -1, -1, "30", FONT_8x8, 0, 1); //从最后一个位置继续写入
//  oledWriteString(&oled, 0, -1, -1, "min", FONT_6x8, 0, 1);
//}
//
//void oled_setup() {
//  rc = oledInit(&oled, OLED_128x32, 0x3c, 0, 0, 0, SDA_PIN, SCL_PIN, RESET_PIN, 1000000L);
//  oledFill(&oled, 0, 1);
////  if (rc != OLED_NOT_FOUND)
////  {
////    oledFill(&oled, 0, 1);
//////    oledSetContrast(&oled, 127);  //Sets the brightness (0=off, 255=brightest)
//////    oledWriteString(&oled, 0, 0, 0, (char *)"Hello World", FONT_8x8, 0, 1);
////  }
//}
